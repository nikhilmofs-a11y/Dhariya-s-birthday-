DHARIYA'S BIRTHDAY SURPRISE — QUICK START

Files:
- index.html: the complete mobile-friendly birthday surprise webpage.

Preview:
- Open index.html in a browser. The surprise, original generated tune, wish button, and local photo preview work in the browser.

Important photo note:
- Photos selected using the page's photo picker are only previews on that device. They do not automatically become visible to Dhariya online.
- For photos to appear in the shared page, upload the photos with the website and edit the HTML to use their published image paths/URLs, or leave the decorative placeholders.

Publish to get a real shareable URL (free option):
1. On a computer, open https://app.netlify.com/drop
2. Sign in or create an account if asked.
3. Upload/drag the folder containing index.html (and any image files you add) onto the page. If the upload requires a ZIP, use the included ZIP file.
4. Wait for the deploy to finish. Netlify will provide a public URL ending in netlify.app.
5. Open that URL on your phone to test it, then send the URL to Dhariya on WhatsApp.

You can also publish with GitHub Pages, but Netlify Drop is usually the quickest for a one-page surprise.
The page has NOT been published by this file creation step, so there is no live URL yet.
